//
//  AddContactsViewController.swift
//  Postr
//
//  Created by Chales.W on 4/19/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI


class AddContactsViewController: UIViewController, EPPickerDelegate, CNContactPickerDelegate{
    
    let del = UIApplication.shared.delegate as! AppDelegate

    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var phonenumber: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var workPlace: UITextField!
    @IBOutlet weak var Notes: UITextField!
    
    override func viewWillAppear(_ animated: Bool) {
        super .viewWillAppear(true)
        let tempInfo = del.tempContactInfo
        var fullInfo = tempInfo.components(separatedBy: ",")
        firstName.text = fullInfo[0]
        lastName.text = fullInfo[1]
        phonenumber.text = fullInfo[2]
        email.text = fullInfo[3]
        workPlace.text = fullInfo[4]
        Notes.text = fullInfo[5]
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(AddContactsViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
}
