//
//  Colors.swift
//  Postr
//
//  Created by Chales.W on 4/23/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import Foundation

class Colors {
    
    var gl:CAGradientLayer!
    
    init() {
        
        
        
        
        
        let randomRedTop:CGFloat = CGFloat(drand48()) * 0.01
        let randomGreenTop:CGFloat = CGFloat(drand48())
        let randomBlueTop:CGFloat = CGFloat(drand48())
        let randomRedBot:CGFloat = CGFloat(drand48()) * 0.01
        let randomGreenBot:CGFloat = CGFloat(drand48())
        let randomBlueBot:CGFloat = CGFloat(drand48())
        
        let colorTop = UIColor(red: randomRedTop,
                               green: randomGreenTop,
                               blue: randomBlueTop, alpha: 1.0).cgColor
        
        let colorBottom = UIColor(red:randomRedBot,
                                  green: randomGreenBot,
                                  blue: randomBlueBot, alpha: 1.0).cgColor
        
        self.gl = CAGradientLayer()
        self.gl.colors = [colorTop, colorBottom]
        self.gl.locations = [0.0, 1.0]
    }
}
