//
//  ContactViewController.swift
//  Postr
//
//  Created by Chales.W on 4/17/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI


class ContactViewController: UIViewController, CNContactPickerDelegate{
    
    let contactStore = CNContactStore.init()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.contactsAuthorization()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func contactsAuthorization(){
        let entityType = CNEntityType.contacts
        let authStatus = CNContactStore.authorizationStatus(for: entityType)
        
        if authStatus == CNAuthorizationStatus.notDetermined{
            
            contactStore.requestAccess(for: entityType, completionHandler: {(sucess, nil) in
                
                if sucess {
                    self.openContacts()
                }else{
                    //print("Not authorized");
                }
            })
        }
        else if authStatus == CNAuthorizationStatus.authorized{
            self.openContacts()
        }
    }

    func openContacts(){
        let contactPicker = CNContactPickerViewController.init()
        contactPicker.delegate = self
        self.present(contactPicker, animated: true, completion: nil)
        
    }
    
    func contactPickerDidCancel(_ picker: CNContactPickerViewController){
        
        self.performSegue(withIdentifier: "unwindToHome", sender: self)
    }
    
    func contactPicker(picker: CNContactPickerViewController, didSelectContact contact: CNContact) {
        
    }
    
 
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
