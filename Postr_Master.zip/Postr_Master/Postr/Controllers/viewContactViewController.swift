//
//  viewContactViewController.swift
//  Nestr
//
//  Created by Alec Eckmann on 4/30/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import Foundation
import Contacts
import ContactsUI

class viewContactViewController : CNContactViewController {
    
}
