//
//  LeftPaneViewController.swift
//  Postr
//
//  Created by Chales.W on 4/16/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import UIKit


class LeftPaneViewController: UIViewController {
    
    let appdelegate = UIApplication.shared.delegate as! AppDelegate
    
    
    
    let qrInfo = String()
    
    @IBOutlet weak var qrImage: UIImageView!
    @IBOutlet weak var displayEmail: UILabel!
    @IBOutlet weak var displayPhone: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 57.0/255.0,
                                            green: 67.0/255.0,
                                            blue: 101.0/255.0, alpha: 1.0)
        let userInfo = appdelegate.userInfo
        let qrInfo = userInfo.joined(separator:",")
        let image = qrCodeImgGen(from: qrInfo)
        qrImage.image = image

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func qrCodeImgGen(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            
            guard let qrCodeImage = filter.outputImage else {return nil}
            let scaleX = qrImage.frame.size.width / qrCodeImage.extent.size.width
            let scaleY = qrImage.frame.size.height / qrCodeImage.extent.size.height
            let transform = CGAffineTransform(scaleX: scaleX, y: scaleY)
            if let output = filter.outputImage?.applying(transform) {
                return UIImage(ciImage: output)
            }
        }
        return nil
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
