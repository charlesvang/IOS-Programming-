//
//  RegisterViewController.swift
//  Postr
//
//  Created by Chales.W on 4/27/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

   let appdelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var workPlace: UITextField!
    @IBOutlet weak var Notes: UITextField!
    
    @IBAction func addUserInfo(_ sender: Any) {
        
        appdelegate.userInfo.append(firstName.text!)
        appdelegate.userInfo.append(lastName.text!)
        appdelegate.userInfo.append(phoneNumber.text!)
        appdelegate.userInfo.append(email.text!)
        appdelegate.userInfo.append(workPlace.text!)
        appdelegate.userInfo.append(Notes.text!)

    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        var gl:CAGradientLayer!
        
        let colorTop = UIColor(red: 42.0/255.0,
                               green: 45.0/255.0,
                               blue: 91.0/255.0, alpha: 1.0).cgColor
        
        let colorBottom = UIColor(red:68.0/255.0,
                                  green: 120.0/255.0,
                                  blue: 218.0/255.0, alpha: 1.0).cgColor
        
        gl = CAGradientLayer()
        gl.colors = [colorTop, colorBottom]
        gl.frame = view.frame
        gl.startPoint = CGPoint(x: 0.0, y: 0.0)
        gl.endPoint = CGPoint(x:0.0, y: 1.0)
        view.backgroundColor = UIColor.clear
        view.layer.insertSublayer(gl, at: 0)
        
        
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(RegisterViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
