//
//  ViewController.swift
//  Postr
//
//  Created by Chales.W on 4/5/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI
import Charts

class SideBarViewController: UIViewController, EPPickerDelegate, UICollectionViewDataSource, UICollectionViewDelegate, ChartViewDelegate{
    
    @IBOutlet weak var pieChartView: PieChartView!
    
    let del = UIApplication.shared.delegate as! AppDelegate
    var tagIndex = 0
    fileprivate let reuseIdentifier = "tagCell"
    
    //@IBOutlet weak var noTagsYet: UILabel!
    @IBOutlet weak var tagCollection: UICollectionView!
    @IBOutlet weak var menuButton: UIBarButtonItem!

    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear( animated)
        pieChartView.reloadInputViews()
        sideMenus()
        self.pieChartView.delegate = self
        var names : [String] = []
        var counts : [Int] = []
        
        for tag in del.tags {
            names.append(tag.name)
            counts.append(tag.relatedContacts.count)
        }
        
        self.setChart(dataPoints: names, values: counts)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func sideMenus(){
        if revealViewController() != nil{
            menuButton.target = revealViewController()
            menuButton.action = #selector(SWRevealViewController.revealToggle(_:))
            revealViewController().rearViewRevealWidth = 350;
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
    }
    
    @IBAction func prepareForUnwind(segue: UIStoryboardSegue){
        
    }
    
    // MARK: cell selection
    
    func collectionView(_ collectionView: UICollectionView,
                        didSelectItemAt indexPath: IndexPath) {
        
        // the index of the tag that the cell refers to is = indexPath.item
        tagIndex = indexPath.item
        performSegue(withIdentifier: "tagView", sender:self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tagView" {
            if let dest = segue.destination as? tagDisplayViewController {
                dest.currTag = del.tags[tagIndex]
            }
        }
    }
    
    //Mark: cell counting
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return del.tags.count
    }
    
    //MARK: cell definition
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! collectionViewCell
        // Use the outlet in our custom class to get a reference to the UILabel in the cell
        var colors: [NSUIColor] = []
        colors = ChartColorTemplates.joyful()
        cell.backgroundColor = colors[indexPath.item]
        cell.label.text = del.tags[indexPath.item].name
        return cell
    }
    
    /** Setting the chart **/
    func setChart(dataPoints: [String], values: [Int]) {
        
        var dataEntries: [ChartDataEntry] = []
        
        for i in 0..<dataPoints.count {
            let dataEntry1 = ChartDataEntry(x: Double(i), y: Double(values[i]), data: dataPoints[i] as AnyObject)
            dataEntries.append(dataEntry1)
        }
        //print(dataEntries[0].data)
        let pieChartDataSet = PieChartDataSet(values: dataEntries, label: "")
        let pieChartData = PieChartData(dataSet: pieChartDataSet)
        
        let mainColor = UIColor(red: 57.0/255.0,
                                green: 66.0/255.0,
                                blue: 100.0/255.0, alpha: 1.0)
        //Background Color
        pieChartView.data = pieChartData
        pieChartView.backgroundColor = mainColor
        
        //Chart Center Text
        var myMutableString = NSMutableAttributedString()
        myMutableString = NSMutableAttributedString(string: "Groups")
        myMutableString.setAttributes([NSFontAttributeName : UIFont(name: "HelveticaNeue-Light", size: CGFloat(20.0))!
            , NSForegroundColorAttributeName : UIColor(red: 255 / 255.0, green: 255 / 255.0, blue: 255 / 255.0, alpha: 1.0)], range: NSRange(location:0,length:6)) // What ever range you want to give
        
        pieChartView.centerAttributedText = myMutableString
        pieChartView.entryLabelColor = mainColor
        pieChartView.chartDescription?.enabled = false
        let legend = pieChartView.legend
        legend.setCustom(colors: [UIColor.clear], labels: [""])
        //Set Slice Colors
        var colors: [NSUIColor] = []
        colors = ChartColorTemplates.joyful()
        pieChartDataSet.colors = colors
        pieChartView.holeColor = UIColor.clear
    }
    
    //Perform Segue when a pie's slice is selected
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        
        if let dataSet = chartView.data?.dataSets[ highlight.dataSetIndex] {
            
            let sliceIndex: Int = dataSet.entryIndex( entry: entry)
            tagIndex = sliceIndex
            performSegue(withIdentifier: "tagView", sender:self)
         }
        
    }
    
}
