//
//  Tag.swift
//  Postr
//
//  Created by Alec Eckmann on 4/17/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import Foundation
import Contacts
import ContactsUI

class Tag {

    var name : String
    var desc : String
    
    /**
    let color : UIColor = UIColor(red: CGFloat(drand48()),
                                  green: CGFloat(drand48()),
                                  blue: CGFloat(drand48()),
                                  alpha: 1)**/
    let color = Colors()
    
    var relatedContacts : [CNContact] = []
    
    init(name: String, desc: String) {
        self.name = name
        self.desc = desc
    }
    
    init(name: String, desc: String, contacts: [CNContact]) {
        self.name = name
        self.desc = desc
        self.relatedContacts.append(contentsOf: contacts)
    }
    
    func addRelatedContact(contact: CNContact) {
        self.relatedContacts.append(contact)
    }
    
}
