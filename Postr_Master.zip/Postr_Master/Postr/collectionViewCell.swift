//
//  collectionViewCell.swift
//  Postr
//
//  Created by Alec Eckmann on 4/18/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import UIKit

class collectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
    
}
