//
//  tableViewCell.swift
//  Postr
//
//  Created by Alec Eckmann on 4/22/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import Foundation

class tableViewCell: UITableViewCell {
    
    @IBOutlet weak var img: UIImageView?
    @IBOutlet weak var txt: UILabel!
    @IBOutlet weak var txt2: UILabel?
}
