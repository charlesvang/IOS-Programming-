//
//  tagCreationViewController.swift
//  Postr
//
//  Created by Alec Eckmann on 4/22/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import Foundation
import Contacts
import ContactsUI

class tagCreationViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, EPPickerDelegate{
    
    let del = UIApplication.shared.delegate as! AppDelegate
    var contactsToAdd : [CNContact] = []
    let reuseIdentifier = "tagCreationContactCell"
    
    var tagCheck : Tag?
    
    var name = ""
    var desc = ""

    
    @IBOutlet weak var tagName: UITextField!
    @IBOutlet weak var contactsTable: UITableView!
    @IBOutlet weak var tagDesc: UITextField!

    @IBAction func createTag(_ sender: Any) {
        if tagName.text == "" {
            self.tagName.layer.borderColor = UIColor.red.cgColor
            self.tagName.layer.borderWidth = 1
            self.tagName.layer.cornerRadius = 5
            self.tagName.becomeFirstResponder()
        } else if tagDesc.text == "" {
            self.tagDesc.layer.borderColor = UIColor.red.cgColor
            self.tagDesc.layer.borderWidth = 1
            self.tagDesc.layer.cornerRadius = 5
            self.tagDesc.becomeFirstResponder()
        } else {
            let tagToCreate = Tag(name:tagName.text!, desc: tagDesc.text!, contacts: contactsToAdd)
            del.tags.append(tagToCreate)
            for (index,contactRelation) in del.contacts {
                if contactsToAdd.contains(where: {($0.givenName == (contactRelation.keys.first)!.givenName)
                                                  && ($0.familyName == (contactRelation.keys.first)!.familyName)}) {
                    del.contacts[index]?[(contactRelation.keys.first)!]?.append(tagToCreate)
                }
            }
            //performSegue(withIdentifier: "goBackToTagView", sender: self)
        }
    }
    
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    //selecting a single or multiple contacts from address book for grouping
    @IBAction func AddContacts(_ sender: Any) {
        let contactPickerScene = EPContactsPicker(delegate: self, multiSelection: true, subtitleCellType: SubtitleCellValue.email)
        let navigationController = UINavigationController(rootViewController: contactPickerScene)
        self.present(navigationController, animated: true, completion: nil)
    }
    
    @IBAction func deleteContactFromTaggedContacts(_ sender: Any) {
        
    }
    
    //MARK: EPContactsPicker delegates
    func epContactPicker(_: EPContactsPicker, didContactFetchFailed error : NSError)
    {
        //print("Failed with error \(error.description)")
    }
    
    func epContactPicker(_: EPContactsPicker, didSelectContact contact : EPContact)
    {
        
        for item in contactsToAdd {
            if item.givenName == contact.firstName && item.familyName == contact.lastName {
                return
            }
        }
        
        let tmpContact = CNMutableContact()
        
        tmpContact.givenName = contact.firstName
        tmpContact.familyName = contact.lastName
        for (email, emailLabel) in contact.emails {
            tmpContact.emailAddresses.append(CNLabeledValue(label: emailLabel, value: email as NSString))
        }
        
        for (phoneNumber, phoneNumberLabel) in contact.phoneNumbers {
            tmpContact.phoneNumbers.append(CNLabeledValue(label: phoneNumberLabel, value: CNPhoneNumber(stringValue: phoneNumber)))
        }
        
        contactsToAdd.append(tmpContact)
        print("Contact \(contact.displayName()) has been selected")
    }
    
    func epContactPicker(_: EPContactsPicker, didCancel error : NSError)
    {
        
    }
    
    func epContactPicker(_: EPContactsPicker, didSelectMultipleContacts contacts: [EPContact]) {
        
        var skip : Bool = false
        
        for contact in contacts {
            
            for item in contactsToAdd {
                if item.givenName == contact.firstName && item.familyName == contact.lastName {
                    skip = true
                }
            }
            
            if (skip) { skip = false; continue }
            
            let tmpContact = CNMutableContact()
            
            tmpContact.givenName = contact.firstName
            tmpContact.familyName = contact.lastName
            for (email, emailLabel) in contact.emails {
                tmpContact.emailAddresses.append(CNLabeledValue(label: emailLabel, value: email as NSString))
            }
            
            for (phoneNumber, phoneNumberLabel) in contact.phoneNumbers {
                tmpContact.phoneNumbers.append(CNLabeledValue(label: phoneNumberLabel, value: CNPhoneNumber(stringValue: phoneNumber)))
            }

            contactsToAdd.append(tmpContact)
            
            print("\(contact.displayName())")
        }
    }
    

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        if (tagName.text == "") {
            self.tagName.text = name
        }
        if (tagDesc.text == "") {
            self.tagDesc.text = desc
        }
        
        contactsTable.reloadData()
        
        self.tagName.becomeFirstResponder()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tagCreationViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            contactsToAdd.remove(at: indexPath.item)
            tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactsToAdd.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! tableViewCell
        
        cell.txt.text = contactsToAdd[indexPath.item].givenName + " " + contactsToAdd[indexPath.item].familyName
        
        return cell
        
    }
}
