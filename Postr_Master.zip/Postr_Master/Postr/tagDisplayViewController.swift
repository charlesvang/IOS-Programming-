//
//  tagCreationViewController.swift
//  Postr
//
//  Created by Alec Eckmann on 4/22/17.
//  Copyright © 2017 nyu.edu. All rights reserved.
//

import Foundation
import Contacts
import ContactsUI

class tagDisplayViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tagDesc: UILabel!
    
    
    let del = UIApplication.shared.delegate as! AppDelegate
    let reuseIdentifier = "contactCell"
    var currTag : Tag! = nil
    var contactToTransfer : CNContact? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tagDesc.text = currTag.desc
        self.title = currTag.name
        _ = navigationController!.navigationBar
        let rightButton = UIBarButtonItem(title: "Edit", style: UIBarButtonItemStyle.plain, target: self, action:  #selector(self.clickOnButton))
        navigationItem.rightBarButtonItem = rightButton
        
    }
    
    func clickOnButton(button: UIButton) {
        //get the current group index 
        
        //Editing ViewController
        
        performSegue(withIdentifier: "editExistingContact", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "editExistingContact") {
            del.tags.remove(at: del.tags.index{
                $0.name == currTag.name
                && $0.desc == currTag.desc
            }!)
            let dvc = segue.destination as! tagCreationViewController
            dvc.tagCheck = currTag
            dvc.name = currTag.name
            dvc.desc = currTag.desc
            dvc.contactsToAdd = currTag.relatedContacts
        }
        else if(segue.identifier == "showContact") {
            let dvc = segue.destination
            let cvc = CNContactViewController(for: contactToTransfer!)
            dvc.addChildViewController(cvc)
            dvc.view.addSubview(cvc.view)
            cvc.didMove(toParentViewController: dvc)
        }
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currTag.relatedContacts.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        contactToTransfer = currTag.relatedContacts[indexPath.item]
        performSegue(withIdentifier: "showContact", sender: self)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! tableViewCell
        
        cell.txt.text = currTag.relatedContacts[indexPath.item].givenName + " " + currTag.relatedContacts[indexPath.item].familyName
        cell.img?.image = UIImage(contentsOfFile: Bundle.main.path(forResource: "user", ofType: "png")!)

        return cell
    }

    
}
